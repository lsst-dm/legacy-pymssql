import pymssql

print(pymssql.get_freetds_version())
