===============
Project history
===============

Evolution of pymssql.

This page stores the most important dates for pymssql project before it moved to
Google Code.

The beginning
=============

The project is registered on SourceForge on 2001-11-14 by 박준철 -- Park
Joon-cheol.

Important releases
==================

* 2001-11-25 - version 0.0.1 for Windows by 박준철
* 2003-02-03 - version 0.2 by 박준철
* 2003-02-14 - version 0.3 by 박준철
* 2003-02-26 - version 0.4 by 박준철
* 2003-06-24 - version 0.5 by 박준철
* 2003-10-21 - version 0.5.1 by 박준철
* 2004-04-09 - version 0.5.2 by 박준철

2005-07 Andrzej Kukuła joins the project.

* 2005-07-23 - version 0.7.1 by Andrzej Kukuła
* 2005-09-05 - version 0.7.2 by Andrzej Kukuła
* 2005-09-05 - version 0.7.3 by Andrzej Kukuła
* 2006-02-23 - version 0.7.4 by Andrzej Kukuła

License change
==============

* 2006-05-03 - 박준철 in his message to SourceForge News announces:

      ,,We decide to change the license. Now, CVS Version is under the LGPL.
      This change of license from GPL to LGPL will be helpful for many F/OSS
      developers.''

LGPLed releases
===============

* 2006-09-24 - version 0.8.0 by Andrzej Kukuła
* 2009-01-29 - version 1.0.0 by Andrzej Kukuła
* 2009-02-05 - version 1.0.1 by Andrzej Kukuła
* 2009-04-28 - version 1.0.2 by Andrzej Kukuła

2009-05 Damien Churchill joins the project in effort to implement better support for stored procedures. However he decides to do much more than that, most important was to rewrite the whole thing in Cython, thus providing support for many more Python versions.

* 2010-02-24 - pre-release 1.9.905 by Damien Churchill
* 2010-02-26 - pre-release 1.9.905.1 by Damien Churchill
